import json
import os
from tkinter import messagebox

SETTINGS_FILE = "settings.json"

DEFAULT_SETTINGS = {
    "theme": {
        "mode": "dark",  # "dark" or "light"
        "waveform_color": "#FF5733",
        "spectrum_color": "#33C3FF",
        "piano_roll_color": "#FFFFFF",
        "background_color": "#1E1E1E"
    },
    "shader": {
        "enabled": True,
        "complexity_mode": "balanced",  # "high_performance", "balanced", "quality"
        "adaptive_speed": False,
        "animation_speed": 1.0
    },
    "audio": {
        "noise_reduction": True,
        "harmonic_enhancement": False,
        "low_cut": 50,
        "high_cut": 15000
    },
    "midi": {
        "legato": False,
        "bpm": 120,
        "velocity_curve": "logarithmic"
    },
    "lock_settings": False  # Prevents accidental changes
}

def load_settings():
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, "r") as file:
            return json.load(file)
    else:
        return DEFAULT_SETTINGS.copy()

def save_settings(settings):
    with open(SETTINGS_FILE, "w") as file:
        json.dump(settings, file, indent=4)

def apply_quick_preset(preset_name):
    settings = load_settings()
    if preset_name == "dark":
        settings["theme"]["mode"] = "dark"
        settings["theme"]["background_color"] = "#1E1E1E"
    elif preset_name == "light":
        settings["theme"]["mode"] = "light"
        settings["theme"]["background_color"] = "#FFFFFF"
    save_settings(settings)
    return settings

def reset_section(section):
    settings = load_settings()
    if section in DEFAULT_SETTINGS:
        settings[section] = DEFAULT_SETTINGS[section]
        save_settings(settings)
    return settings

def toggle_lock():
    settings = load_settings()
    settings["lock_settings"] = not settings.get("lock_settings", False)
    save_settings(settings)
    return settings["lock_settings"]

def reset_animation():
    settings = load_settings()
    if settings["shader"]["adaptive_speed"]:
        settings["shader"]["complexity_mode"] = "high_performance"
    save_settings(settings)
    return settings
